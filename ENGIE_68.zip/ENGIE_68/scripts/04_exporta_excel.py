"""Exporta el analisis exploratorio a Excel.

    uv run python scripts/04_exporta_excel.py            # con los datos de `make data`
    uv run python scripts/04_exporta_excel.py --demo     # precios sinteticos, para probar

El fichero que genera es una SALIDA, no un almacen: se regenera entero cada
vez y nunca se edita a mano. Los datos crudos viven en data/processed en
parquet, que es de donde leen el analisis y los modelos.

Hojas:
    Leeme           que es esto y cuando se genero
    Por regimen     por que no se puede entrenar sobre toda la serie
    Anual           precio, dispersion, horas a cero y spread por anno
    Mensual         la misma serie por meses, con grafico
    Perfil horario  precio medio por hora y anno: la curva del pato
"""

from __future__ import annotations

import argparse
import logging
from datetime import date
from pathlib import Path

import numpy as np
import pandas as pd
import yaml
from openpyxl import Workbook
from openpyxl.chart import LineChart, Reference
import openpyxl.styles
import openpyxl.utils

from pce68.dispatch.battery import Battery, simulate_price_taker
from pce68.features.metrics import daily_spread
from pce68.features.regimenes import anotar, resumen

logging.basicConfig(level=logging.INFO, format="%(message)s")
log = logging.getLogger(__name__)

ROOT = Path(__file__).resolve().parents[1]
AZUL = "1F3864"
F_TIT = openpyxl.styles.Font(name="Arial", size=14, bold=True, color=AZUL)
F_HDR = openpyxl.styles.Font(name="Arial", size=10, bold=True)
F_TXT = openpyxl.styles.Font(name="Arial", size=10)
F_NOTA = openpyxl.styles.Font(name="Arial", size=9, italic=True, color="666666")
FILL_HDR = openpyxl.styles.PatternFill("solid", fgColor="DCE6F1")


def precios_demo(anios: range) -> pd.DataFrame:
    """Serie sintetica con forma solar y un nivel distinto por regimen."""
    rng = np.random.default_rng(7)
    frames = []
    for anio in anios:
        idx = pd.date_range(f"{anio}-01-01", f"{anio}-12-31 23:45", freq="15min", tz="Europe/Madrid")
        h = idx.hour + idx.minute / 60
        nivel = {2021: 90, 2022: 180, 2023: 110, 2024: 65, 2025: 60, 2026: 55}.get(anio, 60)
        valle = 45 * np.clip(np.sin(np.pi * (h - 7) / 12), 0, None) * (1 + (anio - 2021) * 0.12)
        pico = 20 * np.exp(-((h - 21) ** 2) / 3)
        p = nivel - valle + pico + rng.normal(0, 8, len(idx))
        frames.append(
            pd.DataFrame({"timestamp_utc": idx.tz_convert("UTC"), "precio_es": p, "resolucion_min": 15})
        )
    return pd.concat(frames, ignore_index=True)


def celda(v):
    """Convierte un valor de pandas/numpy en algo que openpyxl escriba bien.

    Los NaN tienen que salir como celda vacia: openpyxl los escribe literalmente
    y Excel abre el fichero como danado. En columnas de tipo objeto llegan como
    float de Python, no de numpy, asi que se comprueba cualquier escalar.
    """
    if v is None or (np.isscalar(v) and pd.isna(v)) or v is pd.NaT:
        return None
    if isinstance(v, np.integer):
        return int(v)
    if isinstance(v, np.floating):
        return float(v)
    if isinstance(v, pd.Timestamp):
        return v.tz_localize(None) if v.tzinfo else v
    return v


def tabla(ws, fila0, df: pd.DataFrame, formatos: dict[str, str] | None = None) -> int:
    """Escribe un DataFrame como tabla con cabecera. Devuelve la ultima fila."""
    for j, col in enumerate(df.columns, start=1):
        c = ws.cell(row=fila0, column=j, value=str(col))
        c.font, c.fill = F_HDR, FILL_HDR
        c.alignment = openpyxl.styles.Alignment(wrap_text=True, vertical="center")
        ws.column_dimensions[openpyxl.utils.get_column_letter(j)].width = max(12, min(26, len(str(col)) + 4))

    for i, (_, r) in enumerate(df.iterrows(), start=fila0 + 1):
        for j, col in enumerate(df.columns, start=1):
            c = ws.cell(row=i, column=j, value=celda(r[col]))
            c.font = F_TXT
            if formatos and col in formatos:
                c.number_format = formatos[col]
    return fila0 + len(df)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--demo", action="store_true")
    args = parser.parse_args()

    config = yaml.safe_load((ROOT / "config" / "base.yaml").read_text())
    bat = Battery(
        duracion_horas=config["bateria"]["duracion_horas"],
        eficiencia_ida_vuelta=config["bateria"]["eficiencia_ida_vuelta"],
        ciclos_maximos_anuales=config["bateria"]["ciclos_maximos_anuales"],
    )

    if args.demo:
        log.info("MODO DEMO: precios sinteticos, no son datos reales.")
        precios = precios_demo(range(2021, 2027))
        origen = "DEMO · precios sintéticos. NO son datos de mercado."
    else:
        ruta = ROOT / config["datos"]["processed_dir"] / "precios_omie.parquet"
        if not ruta.exists():
            raise SystemExit(f"No existe {ruta}. Ejecuta antes `make data`, o usa --demo.")
        precios = pd.read_parquet(ruta)
        origen = "Precios del mercado diario de OMIE, descargados con `make data`."

    precios = anotar(precios)
    local = precios["timestamp_utc"].dt.tz_convert("Europe/Madrid")
    precios["anio"] = local.dt.year
    precios["mes"] = local.dt.strftime("%Y-%m")
    precios["hora"] = local.dt.hour
    precios["horas"] = precios["resolucion_min"] / 60.0

    log.info("Calculando spreads diarios...")
    spread2 = daily_spread(precios, 2.0).rename(columns={"spread_2h": "spread"})
    spread2["anio"] = pd.to_datetime(spread2["dia_local"]).dt.year
    spread2["mes"] = pd.to_datetime(spread2["dia_local"]).dt.to_period("M").astype(str)

    log.info("Simulando el despacho de la bateria...")
    ingreso = simulate_price_taker(precios, bat)
    ingreso["anio"] = pd.to_datetime(ingreso["dia"]).dt.year

    # ── Anual
    anual = precios.groupby("anio").apply(
        lambda g: pd.Series(
            {
                "Horas de datos": g["horas"].sum(),
                "Precio medio (€/MWh)": g["precio_es"].mean(),
                "Mediana (€/MWh)": g["precio_es"].median(),
                "Desv. típica (€/MWh)": g["precio_es"].std(),
                "Mínimo (€/MWh)": g["precio_es"].min(),
                "Máximo (€/MWh)": g["precio_es"].max(),
                "Horas a precio ≤ 0": g.loc[g["precio_es"] <= 0, "horas"].sum(),
            }
        ),
        include_groups=False,
    )
    anual["% horas a precio ≤ 0"] = anual["Horas a precio ≤ 0"] / anual["Horas de datos"]
    anual["Spread medio 2 h (€/MWh)"] = spread2.groupby("anio")["spread"].mean()
    anual["Ingreso batería 2 h (€/MW/año)"] = ingreso.groupby("anio")["ingreso_eur_por_mw"].sum()
    anual = anual.reset_index().rename(columns={"anio": "Año"})
    anual["Año"] = anual["Año"].astype(str)

    # ── Mensual
    mensual = precios.groupby("mes").apply(
        lambda g: pd.Series(
            {
                "Precio medio (€/MWh)": g["precio_es"].mean(),
                "Horas a precio ≤ 0": g.loc[g["precio_es"] <= 0, "horas"].sum(),
            }
        ),
        include_groups=False,
    )
    mensual["Spread medio 2 h (€/MWh)"] = spread2.groupby("mes")["spread"].mean()
    mensual = mensual.reset_index().rename(columns={"mes": "Mes"})

    # ── Perfil horario
    perfil = (
        precios.pivot_table(index="hora", columns="anio", values="precio_es", aggfunc="mean")
        .reset_index()
        .rename(columns={"hora": "Hora"})
    )
    perfil.columns = [str(c) for c in perfil.columns]

    # ── Regímenes
    reg = resumen(precios)
    reg = reg.rename(
        columns={
            "regimen": "Régimen",
            "periodos": "Periodos",
            "desde": "Desde",
            "hasta": "Hasta",
            "precio_medio": "Precio medio (€/MWh)",
            "precio_max": "Precio máximo (€/MWh)",
        }
    )

    # ── Escritura
    wb = Workbook()
    eur = "#,##0.00"
    pct = "0.0%"

    ws = wb.active
    ws.title = "Leeme"
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["A"].width = 100
    ws["A1"] = "Proyecto 68 · Análisis exploratorio del mercado diario"
    ws["A1"].font = F_TIT
    textos = [
        f"Generado el {date.today():%d/%m/%Y} por scripts/04_exporta_excel.py",
        origen,
        "",
        "Este fichero es una SALIDA: se regenera entero cada vez que se ejecuta el script.",
        "No lo edites a mano, porque el siguiente `make` sobrescribe los cambios.",
        "",
        "Los datos crudos viven en data/processed/precios_omie.parquet. De ahí leen el análisis",
        "y los modelos de machine learning; Excel solo recibe los agregados, que son los que",
        "una persona puede leer. Medio millón de filas cuarto-horarias no caben aquí de forma útil.",
        "",
        "Las cifras son valores calculados en Python, no fórmulas: la trazabilidad está en el código",
        "y en el control de versiones, no en las celdas.",
    ]
    for i, t in enumerate(textos):
        ws.cell(row=3 + i, column=1, value=t).font = F_TXT if t else F_NOTA

    ws = wb.create_sheet("Por regimen")
    ws.sheet_view.showGridLines = False
    ws["A1"] = "Los cinco años de datos no son un único mercado"
    ws["A1"].font = F_TIT
    ws["A2"] = (
        "Entrenar sobre toda la serie mezcla regímenes que ya no existen. "
        "Solo «normalizacion» representa el mercado que proyectamos a 2031."
    )
    ws["A2"].font = F_NOTA
    tabla(ws, 4, reg, {"Precio medio (€/MWh)": eur, "Precio máximo (€/MWh)": eur})

    ws = wb.create_sheet("Anual")
    ws.sheet_view.showGridLines = False
    ws["A1"] = "Resumen anual"
    ws["A1"].font = F_TIT
    tabla(
        ws,
        3,
        anual,
        {
            "Precio medio (€/MWh)": eur,
            "Mediana (€/MWh)": eur,
            "Desv. típica (€/MWh)": eur,
            "Mínimo (€/MWh)": eur,
            "Máximo (€/MWh)": eur,
            "Horas de datos": "#,##0",
            "Horas a precio ≤ 0": "#,##0",
            "% horas a precio ≤ 0": pct,
            "Spread medio 2 h (€/MWh)": eur,
            "Ingreso batería 2 h (€/MW/año)": "#,##0",
        },
    )

    ws = wb.create_sheet("Mensual")
    ws.sheet_view.showGridLines = False
    ws["A1"] = "Serie mensual"
    ws["A1"].font = F_TIT
    fin = tabla(
        ws,
        3,
        mensual,
        {"Precio medio (€/MWh)": eur, "Horas a precio ≤ 0": "#,##0", "Spread medio 2 h (€/MWh)": eur},
    )
    ch = LineChart()
    ch.title = "Precio medio y spread capturable (€/MWh)"
    ch.height, ch.width = 9, 24
    ch.add_data(Reference(ws, min_col=2, max_col=2, min_row=3, max_row=fin), titles_from_data=True)
    ch.add_data(Reference(ws, min_col=4, max_col=4, min_row=3, max_row=fin), titles_from_data=True)
    ch.set_categories(Reference(ws, min_col=1, min_row=4, max_row=fin))
    ws.add_chart(ch, "F3")

    ws = wb.create_sheet("Perfil horario")
    ws.sheet_view.showGridLines = False
    ws["A1"] = "Precio medio por hora del día"
    ws["A1"].font = F_TIT
    ws["A2"] = "El hundimiento del mediodía que se profundiza año a año es la canibalización solar."
    ws["A2"].font = F_NOTA
    fin = tabla(ws, 4, perfil, {c: eur for c in perfil.columns if c != "Hora"})
    ch = LineChart()
    ch.title = "Perfil horario del precio por año (€/MWh)"
    ch.height, ch.width = 10, 24
    ch.add_data(
        Reference(ws, min_col=2, max_col=len(perfil.columns), min_row=4, max_row=fin),
        titles_from_data=True,
    )
    ch.set_categories(Reference(ws, min_col=1, min_row=5, max_row=fin))
    ws.add_chart(ch, openpyxl.utils.get_column_letter(len(perfil.columns) + 2) + "4")

    salida = ROOT / "reports" / f"analisis_exploratorio{'_demo' if args.demo else ''}.xlsx"
    salida.parent.mkdir(parents=True, exist_ok=True)
    wb.save(salida)
    log.info("\nEscrito %s", salida)
    log.info("\n%s", anual.round(1).to_string(index=False))


if __name__ == "__main__":
    main()
